package ber

import (
    cryptobin_ber "github.com/deatil/go-cryptobin/tool/ber"
)

var Ber2der = cryptobin_ber.Ber2der
