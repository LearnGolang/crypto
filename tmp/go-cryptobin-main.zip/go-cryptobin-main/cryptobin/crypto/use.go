package crypto

// Aes
func (this Cryptobin) Aes() Cryptobin {
    this.multiple = Aes

    return this
}

// Des
func (this Cryptobin) Des() Cryptobin {
    this.multiple = Des

    return this
}

// TwoDes
func (this Cryptobin) TwoDes() Cryptobin {
    this.multiple = TwoDes

    return this
}

// TripleDes
func (this Cryptobin) TripleDes() Cryptobin {
    this.multiple = TripleDes

    return this
}

// Twofish
func (this Cryptobin) Twofish() Cryptobin {
    this.multiple = Twofish

    return this
}

// Blowfish
func (this Cryptobin) Blowfish(salt ...string) Cryptobin {
    this.multiple = Blowfish

    if len(salt) > 0 {
        this.config.Set("salt", []byte(salt[0]))
    }

    return this
}

// Tea
func (this Cryptobin) Tea(rounds ...int) Cryptobin {
    this.multiple = Tea

    if len(rounds) > 0 {
        this.config.Set("rounds", rounds[0])
    }

    return this
}

// Xtea
func (this Cryptobin) Xtea() Cryptobin {
    this.multiple = Xtea

    return this
}

// Cast5
func (this Cryptobin) Cast5() Cryptobin {
    this.multiple = Cast5

    return this
}

// Idea
func (this Cryptobin) Idea() Cryptobin {
    this.multiple = Idea

    return this
}

// SM4
func (this Cryptobin) SM4() Cryptobin {
    this.multiple = SM4

    return this
}

// Chacha20 | Chacha20IETF | XChacha20
func (this Cryptobin) Chacha20(nonce string, counter ...uint32) Cryptobin {
    this.multiple = Chacha20

    this.config.Set("nonce", []byte(nonce))

    if len(counter) > 0 {
        this.config.Set("counter", counter[0])
    }

    return this
}

// Chacha20poly1305
// nonce is 12 bytes
func (this Cryptobin) Chacha20poly1305(nonce string, additional string) Cryptobin {
    this.multiple = Chacha20poly1305

    this.config.Set("nonce", []byte(nonce))
    this.config.Set("additional", []byte(additional))

    return this
}

// Chacha20poly1305X
// nonce is 24 bytes
func (this Cryptobin) Chacha20poly1305X(nonce string, additional string) Cryptobin {
    this.multiple = Chacha20poly1305X

    this.config.Set("nonce", []byte(nonce))
    this.config.Set("additional", []byte(additional))

    return this
}

// RC2
func (this Cryptobin) RC2() Cryptobin {
    this.multiple = RC2

    return this
}

// RC4
func (this Cryptobin) RC4() Cryptobin {
    this.multiple = RC4

    return this
}

// RC4MD5
func (this Cryptobin) RC4MD5() Cryptobin {
    this.multiple = RC4MD5

    return this
}

// RC5
func (this Cryptobin) RC5(wordSize, rounds uint) Cryptobin {
    this.multiple = RC5

    this.config.Set("word_size", wordSize)
    this.config.Set("rounds", rounds)

    return this
}

// Xts
// cipher 可用 [ Aes | Des | TripleDes | Tea | Xtea | Twofish | Blowfish | Cast5 | SM4]
func (this Cryptobin) Xts(cipher string, sectorNum uint64) Cryptobin {
    this.multiple = Xts

    this.config.Set("cipher", cipher)
    this.config.Set("sector_num", sectorNum)

    return this
}

// Salsa20
// key is 32 bytes, nonce is 16 bytes.
func (this Cryptobin) Salsa20(nonce string) Cryptobin {
    this.multiple = Salsa20

    this.config.Set("nonce", []byte(nonce))

    return this
}

// Seed
// The key argument should be 16 bytes.
func (this Cryptobin) Seed() Cryptobin {
    this.multiple = Seed

    return this
}

// Aria
// key is 16, 24, or 32 bytes.
func (this Cryptobin) Aria() Cryptobin {
    this.multiple = Aria

    return this
}

// Camellia
// The key argument should be 16, 24, or 32 bytes.
func (this Cryptobin) Camellia() Cryptobin {
    this.multiple = Camellia

    return this
}

// 使用类型
func (this Cryptobin) MultipleBy(multiple Multiple, cfg ...map[string]any) Cryptobin {
    this.multiple = multiple

    for _, v := range cfg {
        for kk, vv := range v {
            this.config.Set(kk, vv)
        }
    }

    return this
}

// ==========

// 电码本模式
func (this Cryptobin) ECB() Cryptobin {
    this.mode = ECB

    return this
}

// 密码分组链接模式
func (this Cryptobin) CBC() Cryptobin {
    this.mode = CBC

    return this
}

// 填充密码块链接模式
func (this Cryptobin) PCBC() Cryptobin {
    this.mode = PCBC

    return this
}

// 密码反馈模式
func (this Cryptobin) CFB() Cryptobin {
    this.mode = CFB

    return this
}

// 密码反馈模式
func (this Cryptobin) CFB1() Cryptobin {
    this.mode = CFB1

    return this
}

// 密码反馈模式, 8字节
func (this Cryptobin) CFB8() Cryptobin {
    this.mode = CFB8

    return this
}

// 密码反馈模式
func (this Cryptobin) CFB16() Cryptobin {
    this.mode = CFB16

    return this
}

// 密码反馈模式
func (this Cryptobin) CFB32() Cryptobin {
    this.mode = CFB32

    return this
}

// 密码反馈模式
func (this Cryptobin) CFB64() Cryptobin {
    this.mode = CFB64

    return this
}

// 密码反馈模式, 标准库 CFB 别名
func (this Cryptobin) CFB128() Cryptobin {
    this.mode = CFB128

    return this
}

// 输出反馈模式
func (this Cryptobin) OFB() Cryptobin {
    this.mode = OFB

    return this
}

// 输出反馈模式, 8字节
func (this Cryptobin) OFB8() Cryptobin {
    this.mode = OFB8

    return this
}

// 计算器模式
func (this Cryptobin) CTR() Cryptobin {
    this.mode = CTR

    return this
}

// GCM
func (this Cryptobin) GCM(nonce string, additional ...string) Cryptobin {
    this.mode = GCM

    this.config.Set("nonce", []byte(nonce))

    if len(additional) > 0 {
        this.config.Set("additional", []byte(additional[0]))
    }

    return this
}

// CCM
// ccm nounce size, should be in [7,13]
func (this Cryptobin) CCM(nonce string, additional ...string) Cryptobin {
    this.mode = CCM

    this.config.Set("nonce", []byte(nonce))

    if len(additional) > 0 {
        this.config.Set("additional", []byte(additional[0]))
    }

    return this
}

// 使用模式
func (this Cryptobin) ModeBy(mode Mode, cfg ...map[string]any) Cryptobin {
    this.mode = mode

    for _, v := range cfg {
        for kk, vv := range v {
            this.config.Set(kk, vv)
        }
    }

    return this
}

// ==========

// 不补码
func (this Cryptobin) NoPadding() Cryptobin {
    this.padding = NoPadding

    return this
}

// Zero 补码
func (this Cryptobin) ZeroPadding() Cryptobin {
    this.padding = ZeroPadding

    return this
}

// PKCS5 补码
func (this Cryptobin) PKCS5Padding() Cryptobin {
    this.padding = PKCS5Padding

    return this
}

// PKCS7 补码
func (this Cryptobin) PKCS7Padding() Cryptobin {
    this.padding = PKCS7Padding

    return this
}

// X923 补码
func (this Cryptobin) X923Padding() Cryptobin {
    this.padding = X923Padding

    return this
}

// ISO10126 补码
func (this Cryptobin) ISO10126Padding() Cryptobin {
    this.padding = ISO10126Padding

    return this
}

// ISO7816_4 补码
func (this Cryptobin) ISO7816_4Padding() Cryptobin {
    this.padding = ISO7816_4Padding

    return this
}

// ISO97971 补码
func (this Cryptobin) ISO97971Padding() Cryptobin {
    this.padding = ISO97971Padding

    return this
}

// TBC 补码
func (this Cryptobin) TBCPadding() Cryptobin {
    this.padding = TBCPadding

    return this
}

// PKCS1 补码
func (this Cryptobin) PKCS1Padding(bt ...string) Cryptobin {
    this.padding = PKCS1Padding

    if len(bt) > 0 {
        this.config.Set("pkcs1_padding_bt", bt[0])
    }

    return this
}

// 使用补码算法
func (this Cryptobin) PaddingBy(padding Padding, cfg ...map[string]any) Cryptobin {
    this.padding = padding

    for _, v := range cfg {
        for kk, vv := range v {
            this.config.Set(kk, vv)
        }
    }

    return this
}

// ==========

// 不做处理
func (this Cryptobin) NoParse() Cryptobin {
    this.parsedData = this.data

    return this
}
